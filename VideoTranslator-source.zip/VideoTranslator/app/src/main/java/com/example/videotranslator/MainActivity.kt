package com.example.videotranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var mode: Spinner
    private lateinit var engine: Spinner
    private lateinit var baiduAppId: EditText
    private lateinit var baiduKey: EditText
    private lateinit var bingKey: EditText
    private lateinit var bingRegion: EditText
    private lateinit var apiUrl: EditText
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var language: Spinner
    private val projectionRequest = 701
    private val audioRequest = 702
    private val prefs by lazy { getSharedPreferences("translator_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF6F7FB.toInt())
        }
        root.addView(TextView(this).apply { text = "视频翻译悬浮窗"; textSize = 25f; setTextColor(0xFF172033.toInt()); setPadding(0, 0, 0, 8) })
        root.addView(TextView(this).apply { text = "支持跨应用内部音频捕获（需每次授权），也支持麦克风备用模式"; textSize = 14f; setTextColor(0xFF596579.toInt()); setPadding(0, 0, 0, 18) })
        root.addView(label("音频来源"))
        mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("手机内部音频（推荐：捕获视频/播放器声音）", "麦克风（外放声音备用）")) }
        root.addView(mode)
        root.addView(label("离线识别语言"))
        language = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("英语 → 中文", "日语 → 中文", "中文语音")) }
        root.addView(language)
        root.addView(label("翻译引擎"))
        engine = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Google 翻译（实验接口）", "兼容 OpenAI API 的 AI 翻译")) }
        engine.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Google 翻译（无需密钥）", "百度翻译（AppID + 密钥）", "Bing 翻译（Azure Translator）", "兼容 OpenAI API 的 AI 翻译"))
        root.addView(engine)
        root.addView(label("百度 AppID（选择百度翻译时填写）"))
        baiduAppId = edit("百度翻译 AppID"); root.addView(baiduAppId)
        root.addView(label("百度密钥"))
        baiduKey = edit("百度翻译密钥").apply { inputType = 0x81 }; root.addView(baiduKey)
        root.addView(label("Bing/Azure Translator 密钥（选择 Bing 时填写）"))
        bingKey = edit("Azure Translator Key").apply { inputType = 0x81 }; root.addView(bingKey)
        root.addView(label("Bing/Azure 区域（例如 global、eastasia；资源是 global 时可留空）"))
        bingRegion = edit("Azure 区域"); root.addView(bingRegion)
        root.addView(label("AI 翻译接口地址（AI 翻译时需要）"))
        apiUrl = edit("https://你的服务地址/v1/chat/completions"); root.addView(apiUrl)
        root.addView(label("AI API Key（内部音频转文字也使用此 Key）"))
        apiKey = edit("API Key").apply { inputType = 0x81 }; root.addView(apiKey)
        root.addView(label("翻译模型名称"))
        model = edit("例如 gpt-4o-mini"); root.addView(model)
        status = TextView(this).apply { text = "状态：尚未启动"; textSize = 14f; setTextColor(0xFF596579.toInt()); setPadding(0, 16, 0, 12) }; root.addView(status)
        root.addView(Button(this).apply { text = "① 授权显示在其他应用上层"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else status.text = "状态：悬浮窗权限已授权" } })
        root.addView(Button(this).apply { text = "② 启动翻译悬浮窗"; setOnClickListener { startOverlay() } })
        root.addView(Button(this).apply { text = "保存设置"; setOnClickListener { saveSettings(); status.text = "状态：设置已保存" } })
        root.addView(TextView(this).apply { text = "内部音频说明：启动后 Android 会弹出“开始录制或投射屏幕”授权框，请选择允许。语音转文字使用内置离线模型，不上传音频，不需要音频 HTTPS 接口。部分应用（受 DRM 或隐私策略保护）会禁止被捕获，此时请改用麦克风模式。翻译文字仍可能需要网络。"; textSize = 13f; setTextColor(0xFF596579.toInt()); setPadding(0, 16, 0, 0) })
        setContentView(ScrollView(this).apply { addView(root) })
        restoreSettings()
    }
    override fun onPause() { saveSettings(); super.onPause() }
    private fun saveSettings() {
        if (!::mode.isInitialized) return
        prefs.edit().putInt("mode", mode.selectedItemPosition).putInt("language", language.selectedItemPosition).putInt("engine", engine.selectedItemPosition)
            .putString("baiduAppId", baiduAppId.text.toString()).putString("baiduKey", baiduKey.text.toString())
            .putString("bingKey", bingKey.text.toString()).putString("bingRegion", bingRegion.text.toString())
            .putString("apiUrl", apiUrl.text.toString()).putString("apiKey", apiKey.text.toString()).putString("model", model.text.toString()).apply()
    }
    private fun restoreSettings() {
        mode.setSelection(prefs.getInt("mode", 0)); language.setSelection(prefs.getInt("language", 0)); engine.setSelection(prefs.getInt("engine", 0))
        baiduAppId.setText(prefs.getString("baiduAppId", "")); baiduKey.setText(prefs.getString("baiduKey", ""))
        bingKey.setText(prefs.getString("bingKey", "")); bingRegion.setText(prefs.getString("bingRegion", ""))
        apiUrl.setText(prefs.getString("apiUrl", "")); apiKey.setText(prefs.getString("apiKey", "")); model.setText(prefs.getString("model", ""))
    }
    private fun label(s: String) = TextView(this).apply { text = s; textSize = 13f; setTextColor(0xFF39445A.toInt()); setPadding(0, 12, 0, 2) }
    private fun edit(hintText: String) = EditText(this).apply { hint = hintText; textSize = 14f; setSingleLine(true) }
    private fun startOverlay() {
        saveSettings()
        if (!Settings.canDrawOverlays(this)) { status.text = "请先授予悬浮窗权限"; return }
        val internal = mode.selectedItemPosition == 0
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest); return }
        if (internal) { val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(pm.createScreenCaptureIntent(), projectionRequest) }
        else startServiceNow(makeServiceIntent(null))
    }
    private fun makeServiceIntent(projectionData: Intent?): Intent = Intent(this, OverlayService::class.java).apply {
        putExtra("mode", mode.selectedItemPosition); putExtra("engine", engine.selectedItemPosition)
        putExtra("language", language.selectedItemPosition)
        putExtra("apiUrl", apiUrl.text.toString().trim()); putExtra("apiKey", apiKey.text.toString().trim()); putExtra("model", model.text.toString().trim())
        putExtra("baiduAppId", baiduAppId.text.toString().trim()); putExtra("baiduKey", baiduKey.text.toString().trim())
        putExtra("bingKey", bingKey.text.toString().trim()); putExtra("bingRegion", bingRegion.text.toString().trim())
        if (projectionData != null) putExtra("projectionData", projectionData)
    }
    private fun startServiceNow(i: Intent) {
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.text = if (mode.selectedItemPosition == 0) "状态：内部音频捕获已启动，请切换到视频应用" else "状态：麦克风悬浮窗已启动"
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest) { if (resultCode == RESULT_OK && data != null) startServiceNow(makeServiceIntent(data)) else status.text = "未获得内部音频授权；请重新启动并在授权框选择允许" }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequest && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) status.text = "需要麦克风权限才能使用备用模式"
    }
}
