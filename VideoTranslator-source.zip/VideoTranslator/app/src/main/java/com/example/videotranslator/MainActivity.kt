package com.example.videotranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var engine: Spinner
    private lateinit var apiUrl: EditText
    private lateinit var apiKey: EditText
    private lateinit var model: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(0xFFF6F7FB.toInt()) }
        root.addView(TextView(this).apply { text = "视频翻译悬浮窗"; textSize = 25f; setTextColor(0xFF172033.toInt()); setPadding(0,0,0,8) })
        root.addView(TextView(this).apply { text = "第一版测试工程 · 悬浮窗可拖动、可调整大小"; textSize = 14f; setTextColor(0xFF596579.toInt()); setPadding(0,0,0,18) })
        root.addView(label("翻译引擎"))
        engine = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Google 翻译（实验接口）", "兼容 OpenAI API 的 AI 翻译")) }
        root.addView(engine)
        root.addView(label("AI 接口地址（仅选择 AI 时需要，例如兼容 OpenAI 的 /v1/chat/completions）"))
        apiUrl = EditText(this).apply { hint = "https://你的服务地址/v1/chat/completions"; textSize = 14f }
        root.addView(apiUrl)
        root.addView(label("AI API Key（保存在本机；请勿使用有高额权限的主密钥）"))
        apiKey = EditText(this).apply { hint = "API Key"; textSize = 14f; inputType = 0x81 }
        root.addView(apiKey)
        root.addView(label("模型名称"))
        model = EditText(this).apply { hint = "例如 gpt-4o-mini 或服务商支持的模型"; textSize = 14f }
        root.addView(model)
        status = TextView(this).apply { text = "状态：尚未启动"; textSize = 14f; setTextColor(0xFF596579.toInt()); setPadding(0,16,0,12) }
        root.addView(status)
        val grant = Button(this).apply { text = "① 授权显示在其他应用上层"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else status.text = "状态：悬浮窗权限已授权" } }
        root.addView(grant)
        val start = Button(this).apply { text = "② 启动翻译悬浮窗"; setOnClickListener { startOverlay() } }
        root.addView(start)
        root.addView(TextView(this).apply { text = "使用说明：启动后点悬浮窗的麦克风开始收音。麦克风模式会收录手机扬声器播放的声音；蓝牙耳机/耳机播放时可能无法收录。当前版本尚未实现跨应用内部音频捕获。"; textSize = 13f; setTextColor(0xFF596579.toInt()); setPadding(0,16,0,0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 13f; setTextColor(0xFF39445A.toInt()); setPadding(0, 12, 0, 2) }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) { status.text = "请先授予悬浮窗权限"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40); return
        }
        val i = Intent(this, OverlayService::class.java).apply {
            putExtra("engine", engine.selectedItemPosition)
            putExtra("apiUrl", apiUrl.text.toString().trim())
            putExtra("apiKey", apiKey.text.toString().trim())
            putExtra("model", model.text.toString().trim())
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.text = "状态：悬浮窗已启动。请切换到浏览器播放视频，再点悬浮窗麦克风。"
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 40 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startOverlay() else status.text = "需要麦克风权限才能识别视频声音"
    }
}
