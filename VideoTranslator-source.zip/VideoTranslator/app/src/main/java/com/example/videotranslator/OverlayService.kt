package com.example.videotranslator

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.*
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.concurrent.thread

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var speech: SpeechRecognizer? = null
    private var audioRecord: AudioRecord? = null
    private var projection: MediaProjection? = null
    private var captureThread: Thread? = null
    private var listening = false
    private var mode = 0
    private var language = 0
    private var engine = 0
    private var apiUrl = ""
    private var apiKey = ""
    private var model = ""
    private var sttUrl = ""
    private var sttModel = "whisper-1"
    private var speechRetries = 0
    private var localModel: Model? = null
    private lateinit var originalText: TextView
    private lateinit var translatedText: TextView
    private lateinit var statusText: TextView
    private lateinit var listenButton: Button
    private lateinit var params: WindowManager.LayoutParams
    private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getIntExtra("mode", 0) ?: 0
        language = intent?.getIntExtra("language", 0) ?: 0
        engine = intent?.getIntExtra("engine", 0) ?: 0
        apiUrl = intent?.getStringExtra("apiUrl") ?: ""
        apiKey = intent?.getStringExtra("apiKey") ?: ""
        model = intent?.getStringExtra("model") ?: ""
        createNotification()
        if (panel == null) showOverlay()
        if (mode == 0 && projection == null) {
            val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("projectionData", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("projectionData")
            if (data != null) projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(Activity.RESULT_OK, data)
        }
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val id = "video_translator_channel"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(id, "视频翻译悬浮窗", NotificationManager.IMPORTANCE_LOW))
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, id) else Notification.Builder(this)).setContentTitle("视频翻译悬浮窗运行中").setContentText("点击悬浮窗开始或停止识别").setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(10, n, if (mode == 0) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(10, n)
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(240, 20, 27, 43)); setPadding(12, 10, 12, 12) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply { text = "☰  AI 视频翻译"; textSize = 15f; setTextColor(Color.WHITE); setPadding(2, 5, 6, 8) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply { text = "×"; textSize = 24f; setTextColor(Color.WHITE); setPadding(12, 0, 8, 4); setOnClickListener { stopSelf() } })
        root.addView(header)
        statusText = TextView(this).apply { text = if (mode == 0) "内部音频已授权 · 点击开始识别" else "麦克风备用模式 · 点击开始识别"; textSize = 11f; setTextColor(0xFF9FB1D2.toInt()); setPadding(2, 0, 2, 6) }; root.addView(statusText)
        originalText = TextView(this).apply { text = "原文将在这里显示…"; textSize = 13f; setTextColor(0xFFE0E7F4.toInt()); setPadding(2, 5, 2, 5) }; root.addView(originalText)
        translatedText = TextView(this).apply { text = "中文翻译将在这里显示…"; textSize = 16f; setTextColor(Color.WHITE); setPadding(2, 5, 2, 8) }; root.addView(translatedText)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listenButton = Button(this).apply { text = "开始识别"; textSize = 11f; setOnClickListener { if (listening) stopListening() else startListening() } }; controls.addView(listenButton, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply { text = "−"; setOnClickListener { resize(-35, -25) } })
        controls.addView(Button(this).apply { text = "+"; setOnClickListener { resize(35, 25) } })
        root.addView(controls)
        root.addView(TextView(this).apply { text = "拖动顶部移动 · 底部调整大小"; textSize = 10f; setTextColor(0xFF9FB1D2.toInt()); gravity = Gravity.RIGHT; setPadding(0, 3, 2, 0) })
        root.addView(View(this).apply { setBackgroundColor(0xFF7187B7.toInt()); layoutParams = LinearLayout.LayoutParams(-1, 5); setOnTouchListener { _, e -> resizeTouch(e); true } })
        header.setOnTouchListener { _, e -> dragTouch(e); true }
        params = WindowManager.LayoutParams(dp(320), dp(270), if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(24); y = dp(160) }
        panel = root
        try { wm.addView(root, params) } catch (_: Exception) { panel = null; stopSelf() }
    }
    private fun dragTouch(e: MotionEvent): Boolean { when (e.action) { MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y }; MotionEvent.ACTION_MOVE -> { params.x = startX + (e.rawX - downX).toInt(); params.y = startY + (e.rawY - downY).toInt(); update() } }; return true }
    private var rx = 0f; private var ry = 0f; private var rw = 0; private var rh = 0
    private fun resizeTouch(e: MotionEvent) { when (e.action) { MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; rw = params.width; rh = params.height }; MotionEvent.ACTION_MOVE -> { params.width = (rw + (e.rawX - rx).toInt()).coerceIn(dp(240), dp(650)); params.height = (rh + (e.rawY - ry).toInt()).coerceIn(dp(190), dp(700)); update() } } }
    private fun resize(w: Int, h: Int) { params.width = (params.width + w).coerceIn(dp(240), dp(650)); params.height = (params.height + h).coerceIn(dp(190), dp(700)); update() }
    private fun update() { try { panel?.let { wm.updateViewLayout(it, params) } } catch (_: Exception) {} }

    private fun startListening() { if (mode == 0) startPlaybackCapture() else startMicrophoneRecognition() }
    private fun startPlaybackCapture() {
        if (projection == null) { statusText.text = "没有内部音频授权，请关闭后重新启动"; return }
        if (captureThread?.isAlive == true) return
        listening = true; listenButton.text = "停止识别"; statusText.text = "正在捕获其他应用音频…请播放视频"; captureThread = thread(name = "playback-capture") { captureLoop() }
    }
    private fun captureLoop() {
        val rate = 16000; val minBuffer = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        try {
            localModel = Model(prepareModel(if (language == 1) "model-ja" else if (language == 2) "model-cn" else "model-en"))
            val config = AudioPlaybackCaptureConfiguration.Builder(projection!!).addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME).build()
            val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
            audioRecord = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(minBuffer * 2).setAudioPlaybackCaptureConfig(config).build(); audioRecord!!.startRecording()
            val pcm = ByteArray(rate * 2 * 5); val buf = ByteArray(minBuffer)
            while (listening) {
                var offset = 0
                while (offset < pcm.size && listening) { val n = audioRecord!!.read(buf, 0, buf.size); if (n > 0) { val copy = minOf(n, pcm.size - offset); System.arraycopy(buf, 0, pcm, offset, copy); offset += copy } else if (n < 0) throw IllegalStateException("系统音频捕获失败($n)") }
                if (offset > rate && listening) try {
                    handler.post { statusText.text = "正在本地识别内部音频…" }
                    val recognizer = Recognizer(localModel ?: throw IllegalStateException("离线模型未加载"), rate.toFloat())
                    recognizer.acceptWaveForm(pcm, offset)
                    val text = JSONObject(recognizer.finalResult).optString("text").trim()
                    recognizer.close()
                    if (text.isNotBlank()) { handler.post { originalText.text = text }; translate(text) }
                } catch (e: Exception) { handler.post { statusText.text = "本地识别失败：${e.message ?: "请重启识别"}" } }
            }
        } catch (e: Exception) { handler.post { statusText.text = "内部音频不可捕获：${e.message ?: "目标应用可能禁止录音"}" } }
        finally { try { audioRecord?.stop() } catch (_: Exception) {}; audioRecord?.release(); audioRecord = null; try { localModel?.close() } catch (_: Exception) {}; localModel = null; handler.post { listening = false; listenButton.text = "开始识别" } }
    }

    private fun prepareModel(assetName: String): String {
        val target = File(filesDir, assetName)
        if (!File(target, "conf/model.conf").exists()) copyAssetTree(assetName, target)
        return target.absolutePath
    }
    private fun copyAssetTree(assetPath: String, target: File) {
        target.mkdirs()
        for (name in assets.list(assetPath).orEmpty()) {
            val child = "$assetPath/$name"; val out = File(target, name)
            if (assets.list(child).isNullOrEmpty()) assets.open(child).use { input -> out.outputStream().use { input.copyTo(it) } } else copyAssetTree(child, out)
        }
    }

    private fun startMicrophoneRecognition() { if (!SpeechRecognizer.isRecognitionAvailable(this)) { statusText.text = "设备没有可用的语音识别服务"; return }; listening = true; speechRetries = 0; listenButton.text = "停止识别"; startOneSpeechAttempt() }
    private fun startOneSpeechAttempt() {
        if (!listening) return
        speech?.destroy(); speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { statusText.text = "正在聆听麦克风…请让视频外放" }
            override fun onBeginningOfSpeech() { speechRetries = 0 }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "识别完成，正在翻译…" }
            override fun onError(error: Int) {
                if (!listening) return
                speechRetries++; val msg = when (error) { SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "错误 07：没有听到有效语音"; SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "错误 11：语音服务网络超时"; SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "麦克风权限不足"; SpeechRecognizer.ERROR_NO_MATCH -> "没有匹配到语音"; else -> "语音识别错误 $error" }
                statusText.text = "$msg，${if (speechRetries <= 3) "正在自动重试…" else "请检查外放、网络和系统语音服务"}"; if (speechRetries <= 3) handler.postDelayed({ startOneSpeechAttempt() }, 1200) else { listening = false; listenButton.text = "开始识别" }
            }
            override fun onResults(results: Bundle?) { val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); if (text.isNotBlank()) { originalText.text = text; translate(text) }; if (listening) handler.postDelayed({ startOneSpeechAttempt() }, 500) }
            override fun onPartialResults(results: Bundle?) { val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); if (text.isNotBlank()) originalText.text = text }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1) }
        try { speech?.startListening(intent) } catch (e: Exception) { statusText.text = "无法启动语音服务：${e.message}" }
    }
    private fun stopListening() { listening = false; try { speech?.cancel(); speech?.destroy() } catch (_: Exception) {}; try { audioRecord?.stop() } catch (_: Exception) {}; captureThread?.interrupt(); listenButton.text = "开始识别"; statusText.text = "已停止识别" }

    private fun translate(source: String) { handler.post { translatedText.text = "翻译中…" }; thread { val result = try { if (engine == 0) googleTranslate(source) else aiTranslate(source) } catch (e: Exception) { "翻译失败：${e.message ?: "请检查网络或设置"}" }; handler.post { translatedText.text = result; statusText.text = if (mode == 0) "正在继续捕获…" else "本段完成，继续识别中" } } }
    private fun transcribe(audio: ByteArray): String {
        val boundary = "----VideoTranslator${System.currentTimeMillis()}"; val c = URL(sttUrl).openConnection() as HttpURLConnection; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true; c.requestMethod = "POST"; c.setRequestProperty("Authorization", "Bearer $apiKey"); c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { out -> fun field(name: String, value: String) { out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray()) }; field("model", sttModel); out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray()); out.write(audio); out.write("\r\n--$boundary--\r\n".toByteArray()) }
        val code = c.responseCode; val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }; c.disconnect(); if (code !in 200..299) throw IllegalStateException("HTTP $code: ${body.take(160)}"); return JSONObject(body).optString("text").ifBlank { body }
    }
    private fun wav(pcm: ByteArray, rate: Int): ByteArray { val out = ByteArrayOutputStream(); fun i(v: Int) { out.write(byteArrayOf((v and 255).toByte(), ((v shr 8) and 255).toByte(), ((v shr 16) and 255).toByte(), ((v shr 24) and 255).toByte())) }; fun s(v: Int) { out.write(byteArrayOf((v and 255).toByte(), ((v shr 8) and 255).toByte())) }; out.write("RIFF".toByteArray()); i(36 + pcm.size); out.write("WAVEfmt ".toByteArray()); i(16); s(1); s(1); i(rate); i(rate * 2); s(2); s(16); out.write("data".toByteArray()); i(pcm.size); out.write(pcm); return out.toByteArray() }
    private fun googleTranslate(s: String): String { val c = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=zh-CN&dt=t&q=" + URLEncoder.encode(s, "UTF-8")).openConnection() as HttpURLConnection; c.connectTimeout = 10000; c.readTimeout = 15000; try { val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray(0); val out = StringBuilder(); for (i in 0 until arr.length()) out.append(arr.optJSONArray(i)?.optString(0).orEmpty()); return out.toString().ifBlank { "没有获得翻译结果" } } finally { c.disconnect() } }
    private fun aiTranslate(s: String): String { require(apiUrl.startsWith("https://")) { "请填写 HTTPS AI 翻译地址" }; require(apiKey.isNotBlank()) { "请填写 AI API Key" }; require(model.isNotBlank()) { "请填写模型名称" }; val c = URL(apiUrl).openConnection() as HttpURLConnection; c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer $apiKey"); val body = JSONObject().put("model", model).put("temperature", 0.2).put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "你是专业字幕翻译。只输出简体中文译文。" )).put(JSONObject().put("role", "user").put("content", s))).toString(); c.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }; val code = c.responseCode; val json = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }; c.disconnect(); if (code !in 200..299) throw IllegalStateException("HTTP $code: ${json.take(160)}"); return JSONObject(json).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { stopListening(); try { projection?.stop() } catch (_: Exception) {}; try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}; panel = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
