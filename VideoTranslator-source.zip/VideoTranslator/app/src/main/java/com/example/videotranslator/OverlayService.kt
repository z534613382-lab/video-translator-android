package com.example.videotranslator

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.concurrent.thread

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var speech: SpeechRecognizer? = null
    private var listening = false
    private var engine = 0
    private var apiUrl = ""
    private var apiKey = ""
    private var model = ""
    private lateinit var originalText: TextView
    private lateinit var translatedText: TextView
    private lateinit var statusText: TextView
    private lateinit var listenButton: Button
    private lateinit var params: WindowManager.LayoutParams
    private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        engine = intent?.getIntExtra("engine", 0) ?: 0
        apiUrl = intent?.getStringExtra("apiUrl") ?: ""
        apiKey = intent?.getStringExtra("apiKey") ?: ""
        model = intent?.getStringExtra("model") ?: ""
        createNotification()
        if (panel == null) showOverlay()
        return START_STICKY
    }
    private fun createNotification() {
        val channel = "video_translator_channel"
        if (Build.VERSION.SDK_INT >= 26) { val c = NotificationChannel(channel, "视频翻译悬浮窗", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(c) }
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        startForeground(10, n.setContentTitle("视频翻译悬浮窗运行中").setContentText("点击悬浮窗开始或停止语音识别").setSmallIcon(android.R.drawable.ic_menu_info_details).build())
    }
    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(235, 20, 27, 43)); setPadding(12, 10, 12, 12) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply { text = "☰  AI 视频翻译"; textSize = 15f; setTextColor(Color.WHITE); setPadding(2, 5, 6, 8) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val close = TextView(this).apply { text = "×"; textSize = 24f; setTextColor(Color.WHITE); setPadding(12,0,8,4); setOnClickListener { stopSelf() } }
        header.addView(close)
        root.addView(header)
        statusText = TextView(this).apply { text = "就绪 · 拖动顶部移动窗口"; textSize = 11f; setTextColor(0xFF9FB1D2.toInt()); setPadding(2,0,2,6) }
        root.addView(statusText)
        originalText = TextView(this).apply { text = "原文将在这里显示…"; textSize = 13f; setTextColor(0xFFE0E7F4.toInt()); setPadding(2,5,2,5) }
        root.addView(originalText)
        translatedText = TextView(this).apply { text = "中文翻译将在这里显示…"; textSize = 16f; setTextColor(Color.WHITE); setPadding(2,5,2,8) }
        root.addView(translatedText)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listenButton = Button(this).apply { text = "开始收音"; textSize = 11f; setOnClickListener { if (listening) stopListening() else startListening() } }
        controls.addView(listenButton, LinearLayout.LayoutParams(0, -2, 1f))
        val smaller = Button(this).apply { text = "−"; setOnClickListener { resize(-35, -25) } }
        controls.addView(smaller)
        val bigger = Button(this).apply { text = "+"; setOnClickListener { resize(35, 25) } }
        controls.addView(bigger)
        root.addView(controls)
        val footer = TextView(this).apply { text = "拖右下角 ↘ 调整大小"; textSize = 10f; setTextColor(0xFF9FB1D2.toInt()); gravity = Gravity.RIGHT; setPadding(0,3,2,0) }
        root.addView(footer)
        val handle = View(this).apply { setBackgroundColor(0xFF7187B7.toInt()); layoutParams = LinearLayout.LayoutParams(-1, 5); setOnTouchListener { _, e -> resizeTouch(e); true } }
        root.addView(handle)
        header.setOnTouchListener { _, e -> dragTouch(e); true }
        params = WindowManager.LayoutParams(dp(300), dp(240), if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(24); y = dp(160) }
        panel = root
        try { wm.addView(root, params) } catch (_: Exception) { panel = null; stopSelf() }
    }
    private fun dragTouch(e: MotionEvent): Boolean { when(e.action) { MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y }; MotionEvent.ACTION_MOVE -> { params.x=startX+(e.rawX-downX).toInt(); params.y=startY+(e.rawY-downY).toInt(); update() } }; return true }
    private var resizeDownX=0f; private var resizeDownY=0f; private var resizeW=0; private var resizeH=0
    private fun resizeTouch(e: MotionEvent) { when(e.action) { MotionEvent.ACTION_DOWN -> { resizeDownX=e.rawX; resizeDownY=e.rawY; resizeW=params.width; resizeH=params.height }; MotionEvent.ACTION_MOVE -> { params.width=(resizeW+(e.rawX-resizeDownX).toInt()).coerceIn(dp(220),dp(600)); params.height=(resizeH+(e.rawY-resizeDownY).toInt()).coerceIn(dp(170),dp(700)); update() } } }
    private fun resize(w:Int,h:Int) { params.width=(params.width+w).coerceIn(dp(220),dp(600)); params.height=(params.height+h).coerceIn(dp(170),dp(700)); update() }
    private fun update() { try { panel?.let { wm.updateViewLayout(it, params) } } catch (_: Exception) {} }
    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { statusText.text = "此设备没有可用的语音识别服务"; return }
        speech?.destroy(); speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { statusText.text = "正在聆听视频声音…" }
            override fun onBeginningOfSpeech() { }
            override fun onRmsChanged(rmsdB: Float) { }
            override fun onBufferReceived(buffer: ByteArray?) { }
            override fun onEndOfSpeech() { statusText.text = "识别完成，正在翻译…" }
            override fun onError(error: Int) { listening=false; listenButton.text="开始收音"; statusText.text="识别中断（错误 $error），可重新开始" }
            override fun onResults(results: android.os.Bundle?) { val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); if (text.isNotBlank()) { originalText.text=text; translate(text) }; listening=false; listenButton.text="开始收音" }
            override fun onPartialResults(partialResults: android.os.Bundle?) { val text=partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); if(text.isNotBlank()) originalText.text=text }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) { }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1) }
        try { speech?.startListening(intent); listening=true; listenButton.text="停止收音" } catch (e: Exception) { statusText.text="无法启动识别：${e.message}" }
    }
    private fun stopListening() { try { speech?.stopListening() } catch (_: Exception) {}; listening=false; listenButton.text="开始收音"; statusText.text="已停止收音" }
    private fun translate(source: String) {
        translatedText.text = "翻译中…"
        thread {
            val result = try { if (engine == 0) googleTranslate(source) else aiTranslate(source) } catch (e: Exception) { "翻译失败：${e.message ?: "请检查网络或设置"}" }
            runOnMain { translatedText.text=result; statusText.text="本段翻译完成 · 再次收音可继续" }
        }
    }
    private fun googleTranslate(s: String): String {
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=zh-CN&dt=t&q=" + URLEncoder.encode(s, "UTF-8"))
        val c=url.openConnection() as HttpURLConnection; c.connectTimeout=10000; c.readTimeout=15000; c.setRequestProperty("User-Agent","Mozilla/5.0")
        try { val json=c.inputStream.bufferedReader().use { it.readText() }; val arr=org.json.JSONArray(json).getJSONArray(0); val out=StringBuilder(); for(i in 0 until arr.length()) { val seg=arr.optJSONArray(i); if(seg!=null) out.append(seg.optString(0)) }; return out.toString().ifBlank { "没有获得翻译结果" } } finally { c.disconnect() }
    }
    private fun aiTranslate(s: String): String {
        require(apiUrl.startsWith("https://")) { "请在主界面填写 HTTPS AI 接口地址" }; require(apiKey.isNotBlank()) { "请填写 AI API Key" }; require(model.isNotBlank()) { "请填写模型名称" }
        val c=URL(apiUrl).openConnection() as HttpURLConnection; c.requestMethod="POST"; c.connectTimeout=15000; c.readTimeout=30000; c.doOutput=true; c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer $apiKey")
        val body=JSONObject().put("model",model).put("temperature",0.2).put("messages", JSONArray().put(JSONObject().put("role","system").put("content","你是专业字幕翻译。把用户给出的语音识别文本准确、自然地翻译成简体中文，只输出译文。保留专有名词和语气。" )).put(JSONObject().put("role","user").put("content",s))).toString()
        c.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
        try { val stream=if(c.responseCode in 200..299) c.inputStream else c.errorStream; val json=stream.bufferedReader().use{it.readText()}; if(c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}: ${json.take(180)}"); return JSONObject(json).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim() } finally { c.disconnect() }
    }
    private fun runOnMain(f:()->Unit) { android.os.Handler(mainLooper).post(f) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onDestroy() { try { speech?.destroy() } catch (_:Exception) {}; try { panel?.let { wm.removeView(it) } } catch (_:Exception) {}; panel=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
