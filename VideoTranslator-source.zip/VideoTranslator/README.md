# 视频翻译悬浮窗

这是一个 Android 原生悬浮窗视频翻译工具，支持两种音频来源：

- **手机内部音频**：通过 Android `MediaProjection + AudioPlaybackCapture` 捕获浏览器、播放器等应用播放的媒体音频，再按 5 秒分段发送到兼容 OpenAI `/v1/audio/transcriptions` 的 HTTPS 服务转写，最后翻译成中文。
- **麦克风备用模式**：适合手机外放声音；会自动处理错误 07（语音超时）和错误 11（网络超时）并重试。

## 内部音频模式配置

1. 在主界面选择“手机内部音频”。
2. 填写兼容 OpenAI 的音频转文字地址，例如 `https://服务地址/v1/audio/transcriptions`。
3. 填写 API Key 和音频模型，例如 `whisper-1`。
4. 启动后在 Android 系统授权框选择允许录制/投射，切换到视频应用播放，再点击悬浮窗的“开始识别”。
5. 如果目标应用启用了 DRM 或禁止 AudioPlaybackCapture，Android 会返回空音频，此时只能使用麦克风备用模式。

## 翻译配置

Google 翻译模式使用实验性接口，无需翻译 API Key，但内部音频转写仍需要音频转写服务。AI 翻译模式需要填写兼容 OpenAI Chat Completions 的 HTTPS 地址、API Key 和模型名称。

## 错误说明

- 错误 07：`ERROR_SPEECH_TIMEOUT`，系统语音服务没有听到有效麦克风语音。请外放视频、靠近扬声器，或改用内部音频模式。
- 错误 11：`ERROR_NETWORK_TIMEOUT`，系统语音服务网络超时。应用会自动重试 3 次；若仍失败，请检查网络或系统语音识别服务。
- 内部音频模式不依赖 Android `SpeechRecognizer`，因此不会再因为系统语音服务错误 07/11 而直接失败。
