# 视频翻译悬浮窗（Android 原生工程）

当前工程是可继续构建的 MVP 源码，包含：
- Android 原生悬浮窗 Service
- 顶部拖动移动
- 右下角拖拽改变窗口宽高，另有 +/- 尺寸按钮
- 麦克风语音识别（依赖设备上可用的 Android SpeechRecognizer 服务）
- Google 翻译实验性 Web 接口
- OpenAI-compatible Chat Completions API 翻译引擎

## 重要限制
- 当前版本**不是已验证可安装的 APK**，本工作环境未提供 Android SDK/Gradle 构建环境。
- 当前版本通过麦克风听扬声器外放声音，不能直接捕获其他应用内部播放音频；若使用耳机，麦克风可能听不到视频声音。
- Google `translate.googleapis.com/translate_a/single?client=gtx` 是非正式接口，可能限流或变化，不应视为稳定的官方 API。正式长期使用建议改为 Google Cloud Translation API 并配置凭据。
- AI 模式需在应用内配置兼容 OpenAI Chat Completions 的 HTTPS 地址、API Key 和模型名。API Key 会由应用发送至所配置服务商；请勿填入不可信服务地址。
- Android 版本、厂商后台策略和语音识别服务会影响长时间识别能力。当前是分段识别原型，不是无缝实时字幕。

## 用 Android Studio 构建
1. 安装 Android Studio（建议稳定版）及 Android SDK 35。
2. 打开本目录 `VideoTranslator`。
3. 等待 Gradle Sync 完成；如果插件版本或 SDK 下载失败，按 Android Studio 提示安装对应组件。
4. 使用真机运行，授予麦克风和“显示在其他应用上层”权限。
5. 点击“启动翻译悬浮窗”，切换到浏览器播放视频，再点击悬浮窗“开始收音”。
6. 若需要 APK：Android Studio 菜单 Build → Build APK(s)。

## 后续建议
1. 增加 MediaProjection + AudioPlaybackCapture 内部音频捕获（只支持符合 Android 音频捕获策略的应用，并需用户每次授权）。
2. 加入连续分段识别、自动续听、时间戳与历史记录。
3. 正式 Google Cloud Translation API 或可配置 AI Provider 设置页。
4. 对目标手机和浏览器实测后再发布安装包。
